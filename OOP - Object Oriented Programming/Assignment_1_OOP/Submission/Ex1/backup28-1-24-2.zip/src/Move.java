import java.util.ArrayList;

public class Move {
    private Position from;
    private Position to;
    private ArrayList<ConcretePiece> killed;
    private ConcretePiece killer;
    public Move(Position from, Position to) {
        this.from = from;
        this.to = to;
        this.killer = null;
        this.killed = new ArrayList<>();
    }

    public void addKill(ConcretePiece killer, ConcretePiece killed) {
        this.killer = killer;
        this.killed.add(killed);
    }

    public Position getFrom() {
        return this.from;
    }

    public Position getTo() {
        return this.to;
    }

    public ArrayList<ConcretePiece> getKilledList() {
        return this.killed;
    }

    public Pawn getKiller() {
        return (Pawn)this.killer;
    }

}
