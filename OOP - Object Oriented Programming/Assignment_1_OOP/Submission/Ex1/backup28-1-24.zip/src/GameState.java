import java.util.ArrayList;
import java.util.Stack;

public class GameState {
    private Stack<ConcretePiece[][]> boardPieces;

    private Stack<PieceStats[][]> pieceStats;

    private Stack<PositionStats[][]> positionStats;


    private int numberOfStates;

    public GameState(){
        boardPieces = new Stack<>();
        pieceStats = new Stack<>();
        positionStats = new Stack<>();
        numberOfStates = 0;
    }

    public void addState(ConcretePiece[][] boardPieces1, PieceStats[][] pieceStats1, PositionStats[][] positionStats1) {
        boardPieces.push(deepCopy(boardPieces1));
        pieceStats.push(deepCopy(pieceStats1));
        positionStats.push(deepCopy(positionStats1));
        numberOfStates++;
    }

    public void removeState() {
        boardPieces.pop();
        pieceStats.pop();
        positionStats.pop();
        numberOfStates--;
    }

    public ConcretePiece[][] getLast_boardPieces() {
        return deepCopy(boardPieces.peek());
    }

    public PieceStats[][] getLast_pieceStats() {
        return deepCopy(pieceStats.peek());
    }

    public PositionStats[][] getLast_positionStats() {
        return deepCopy(positionStats.peek());
    }

    public int getNumberOfStates() {
        return numberOfStates;
    }

    public static ConcretePiece[][] deepCopy(ConcretePiece[][] concretePiece) {
        ConcretePiece[][] clone = new ConcretePiece[concretePiece.length][];

        for (int i = 0; i < clone.length; i++) {
            clone[i] = concretePiece[i].clone();
        }

        return clone;
    }

    public static PieceStats[][] deepCopy(PieceStats[][] pieceStats1) {
        PieceStats[][] clone = new PieceStats[pieceStats1.length][];

        for (int i = 0; i < clone.length; i++) {
            clone[i] = pieceStats1[i].clone();
        }

        return clone;
    }

    public static PositionStats[][] deepCopy(PositionStats[][] positionStats) {
        PositionStats[][] clone = new PositionStats[positionStats.length][];

        for (int i = 0; i < clone.length; i++) {
            clone[i] = positionStats[i].clone();
        }

        return clone;
    }
}
