public class King extends ConcretePiece {
    public static final String KING_1 = "♔";

    public King(Player owner) {
        super(owner);
    }
}
